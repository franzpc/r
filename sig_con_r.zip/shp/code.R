## Instalamos las librer�as si hace falta
if(!require("sf"))install.packages("sf")
if(!require("ggplot2"))install.packages("ggplot2")
if(!require("ggrid"))install.packages("grid")
if(!require("ggsn"))install.packages("ggsn")
if(!require("ggspatial"))install.packages("ggspatial")

## Activar la librer�as
library(sf)
library(ggplot2)
library(grid)
library(ggsn)
library(ggspatial)

## Establecer la ruta del directorio
setwd("D:\\R\\shp")
setwd("D:/R/shp")

## A�adir las capas vectoriales
Poblados <- st_read("Poblados.shp")
Rios <- st_read("Torrente.shp")
Vias <- st_read("D:/R/shp/Vias.shp")
Cobertura <- st_read("D:/R/shp/Cobertura.shp")

## Tipo de geometr�a
st_geometry_type(Poblados)
st_geometry_type(Vias)

## Sistema de coordenadas
st_crs(Poblados)
st_crs(Cobertura)

## Extensi�n espacial
st_bbox(Vias)

## Metadatos
Rios

## Plot
plot(Poblados)
plot(Rios)
plot(Vias)
plot(Cobertura)

## Plot con ggplot2
ggplot() +
  geom_sf(data = Vias, aes(color = Tipo)) +
  ggtitle("Mi primer mapa con RStudio") 

## A�adir puntos GPS

GPS <- data.frame(longitud = c(690000, 694000), latitud = c(9533000, 9531550), name = c("P1", "P2"))
plot(GPS)

## Plotear varias capas
ggplot() +
  geom_sf(data = Cobertura, aes(fill = Tipo)) +
  geom_sf(data = Vias, aes(color = Tipo)) +
  geom_sf(data = Poblados, size = 4, color = "Brown") +
  geom_sf(data = Rios, color = "blue", lwd = 1) +
  north(data = Cobertura, symbol = 12) +
  ggspatial::annotation_scale(location = "br") +
  coord_sf(datum=st_crs(32717)) +
  geom_point(data = GPS, aes(x = longitud, y = latitud), size = 4, shape = 23, fill = "black") +
  geom_label(data = GPS, aes(x = longitud, y = latitud, label = name), size = 2)+
  ggtitle("Mi primer mapa con RStudio") +
  annotate(geom = "text", x = 690000, y = 9534550, label = "�rea de estudio") +
  annotate(geom = "text", x = 695000, y = 9531500, label = "@franzpc")
  
